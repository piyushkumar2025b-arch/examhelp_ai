"""
key_manager.py — Secure, rate-limit-aware Groq API key rotation.

- All 8 keys are stored here only (never in app.py or .env).
- Each key has its own cooldown tracker and usage counter.
- Keys are selected via least-recently-used + cooldown logic.
- If a key hits a rate limit it is cooled down for COOLDOWN_SECONDS,
  then automatically re-entered into rotation.
- The module is entirely stateless w.r.t. Streamlit; it uses a
  module-level dict so state persists across reruns within the same
  Streamlit process.
"""

from __future__ import annotations
import time
import threading
from typing import Optional

# ─────────────────────────────────────────────────────────────────────────────
# 🔑  ALL KEYS — edit ONLY here; never paste keys anywhere else
# ─────────────────────────────────────────────────────────────────────────────
_RAW_KEYS: list[str] = [
    "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",  # key 1 (original primary)
    "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",  # key 2
    "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",  # key 3
    "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",  # key 4
    "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",  # key 5
    "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",  # key 6
    "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",  # key 7
    "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",  # key 8
]

# ─────────────────────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────────────────────
COOLDOWN_SECONDS: float = 62.0   # Groq free tier resets every ~60 s
MAX_RETRIES: int = len(_RAW_KEYS) * 2  # try every key twice before giving up

# ─────────────────────────────────────────────────────────────────────────────
# Per-key state  (module-level → survives Streamlit reruns in same process)
# ─────────────────────────────────────────────────────────────────────────────
_lock = threading.Lock()

_state: dict[str, dict] = {
    k: {
        "cooldown_until": 0.0,   # epoch seconds; 0 = available now
        "uses": 0,               # lifetime successful uses
        "errors": 0,             # lifetime rate-limit/auth errors
        "last_used": 0.0,        # epoch seconds of last use
    }
    for k in _RAW_KEYS
}


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def get_key(override: Optional[str] = None) -> Optional[str]:
    """
    Return the best available key right now.

    Priority:
    1. `override` key if provided (user-supplied key from UI / .env).
    2. Least-recently-used key that is not in cooldown.
    3. The key with the *soonest* cooldown expiry (no truly-available key).
    4. None — all keys cooling down and none registered.
    """
    if override and override.strip():
        return override.strip()

    now = time.time()
    with _lock:
        available = [k for k in _RAW_KEYS if _state[k]["cooldown_until"] <= now]
        if available:
            # pick LRU among available
            return min(available, key=lambda k: _state[k]["last_used"])

        # all cooling — pick the one that recovers soonest
        if _RAW_KEYS:
            return min(_RAW_KEYS, key=lambda k: _state[k]["cooldown_until"])

    return None


def mark_used(key: str) -> None:
    """Record a successful API call for this key."""
    with _lock:
        if key in _state:
            _state[key]["uses"] += 1
            _state[key]["last_used"] = time.time()


def mark_rate_limited(key: str) -> None:
    """Put a key in cooldown after a 429 / rate-limit error."""
    with _lock:
        if key in _state:
            _state[key]["errors"] += 1
            _state[key]["cooldown_until"] = time.time() + COOLDOWN_SECONDS


def mark_invalid(key: str) -> None:
    """Permanently disable a key (auth failure, invalid key)."""
    with _lock:
        if key in _state:
            _state[key]["errors"] += 1
            # Set cooldown to far future — effectively disabled
            _state[key]["cooldown_until"] = time.time() + 86_400 * 365


def seconds_until_available(key: str) -> float:
    """How many seconds until this key exits cooldown (0 if available now)."""
    with _lock:
        return max(0.0, _state[key]["cooldown_until"] - time.time())


def status_table() -> list[dict]:
    """
    Return a list of dicts describing every key's current state.
    Safe for display in UI — keys are partially masked.
    """
    now = time.time()
    rows = []
    with _lock:
        for i, k in enumerate(_RAW_KEYS, 1):
            s = _state[k]
            cd = s["cooldown_until"]
            if cd > now:
                status = f"⏳ cooldown {cd - now:.0f}s"
            else:
                status = "✅ available"
            rows.append({
                "key": f"Key #{i}  ({k[:8]}…{k[-4:]})",
                "status": status,
                "uses": s["uses"],
                "errors": s["errors"],
            })
    return rows


def reset_all_cooldowns() -> None:
    """Admin helper — clears all cooldowns (useful after a manual reset)."""
    with _lock:
        for k in _RAW_KEYS:
            _state[k]["cooldown_until"] = 0.0
